﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Comple3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Thread thread1 = new Thread(new ThreadStart(DoTask1));
            thread1.Start();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Thread thread2 = new Thread(new ThreadStart(DoTask2));
            thread2.Start();
        }


        private void DoTask1()
        {
            // Simulamos una tarea larga para el primer hilo
            for (int i = 0; i < 10; i++)
            {
                Thread.Sleep(1000); // Simula una operación que tarda 1 segundo
                UpdateStatus("Tarea 1: Iteración " + (i + 1));
            }
        }

        private void DoTask2()
        {
            // Simulamos una tarea larga para el segundo hilo
            for (int i = 0; i < 10; i++)
            {
                Thread.Sleep(1500); // Simula una operación que tarda 1.5 segundos
                UpdateStatus("Tarea 2: Iteración " + (i + 1));
            }
        }

        private void UpdateStatus(string status)
        {
            // Actualiza el texto en el cuadro de texto de la interfaz de usuario
            if (textBox1.InvokeRequired)
            {
                textBox1.Invoke(new Action(() => { UpdateStatus(status); }));
            }
            else
            {
                textBox1.AppendText(status + Environment.NewLine);
            }
        }
    }
}
